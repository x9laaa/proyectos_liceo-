public class Pokemon {
    private String nombre;
    private int vida;

    public Pokemon(String nombre, int vida) {
        this.nombre = nombre;
        this.vida = vida;
    }

    public String getNombre() {
        return nombre;
    }

    public int getVida() {
        return vida;
    }

    public void setVida(int vida) {
        this.vida = vida;
    }

    public void mostrarInformacion() {
        System.out.println("Nombre: " + nombre);
        System.out.println("Vida: " + vida);
    }

    public void atacar(Pokemon enemigo) {
        int danio = (int) (Math.random() * 20) + 1; // Daño aleatorio entre 1 y 20
        System.out.println(nombre + " ataca a " + enemigo.getNombre() + " causando " + danio + " de daño.");
        enemigo.setVida(enemigo.vida - danio);
    }

    public void estado() {
        if (vida > 0) {
            System.out.println(nombre + " está vivo con " + vida + " de vida.");
        } else {
            System.out.println(nombre + " ha sido derrotado.");
        }
    }

    
}
