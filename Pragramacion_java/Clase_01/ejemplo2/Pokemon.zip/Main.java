public class Main {
    public static void main(String[] args) {
        Pokemon p1 = new Pokemon("Pikachu", 100);
        Pokemon p2 = new Pokemon("Charmander", 100);

        p1.mostrarInformacion();
        p2.mostrarInformacion();

        while (p1.getVida() > 0 && p2.getVida() > 0) {
            p1.atacar(p2);
            p2.estado();

            if (p2.getVida() > 0) {
                p2.atacar(p1);
                p1.estado();
            }
        }
    }
    
}
